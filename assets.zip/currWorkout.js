import { initializeApp } from "https://www.gstatic.com/firebasejs/9.15.0/firebase-app.js"
import { getDatabase, ref, push, onValue, remove } from "https://www.gstatic.com/firebasejs/9.15.0/firebase-database.js"

const appSettings = {
    databaseURL: "https://gym-web-app-ae185-default-rtdb.asia-southeast1.firebasedatabase.app/"
}

const app = initializeApp(appSettings);
const database = getDatabase(app);
const workouts = ref(database, "workouts")

const mainEl = document.querySelector(".main")
const topBarEl = document.querySelector(".top-bar")
const exerciseEl = document.querySelector(".exercise")


onValue(workouts, function(snapshot) {
    if (snapshot.exists()) {
        let itemsArr = Object.entries(snapshot.val());

        // Assuming we're processing only the first workout for now
        let currentItem = itemsArr[0];
        let exercises = Object.entries(currentItem[1]);
        clearExercises(); // Clear previous exercises
        exercises.forEach(([exerciseName, exerciseDetails]) => {
            addExercises(exerciseName, exerciseDetails);
        });
    } else {
        console.log("No data from realtime database");
    }
});

function formatCamelCase(str) {
    const spacedString = str.replace(/([A-Z])/g, " $1");
    return spacedString
        .trim()
        .split(" ")
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(" ");
}

const addExercises = (exerciseName, exerciseDetails) => {
    const exerciseHTML = `
        <div class="exercise-section">
            <h3>${formatCamelCase(exerciseName)}</h3>
            <div class="grid-container">
                <div class="exercise-header">
                    <span class="header">Set</span>
                    <span class="header">KG</span>
                    <span class="header">REPS</span>
                    <span></span>
                </div>
            </div>
        </div>
    `;

    // Append the new exercise section
    exerciseEl.innerHTML += exerciseHTML;

    // Add sets dynamically
    const gridContainer = exerciseEl.querySelector(".exercise-section:last-child .grid-container");
    for (let i = 0; i < exerciseDetails.sets; i++) {
        const setDetails = `
            <div class="set">
                <span class="row">${i + 1}</span>
                <input type="number" min="0" value="${exerciseDetails['weight']}">
                <input type="number" min="0" step="1" value="${exerciseDetails['reps']}">
                <input type="checkbox" value="exercise-${i + 1}-done">
            </div>
        `;
        gridContainer.innerHTML += setDetails;
    }
};

const clearExercises = () => {
    exerciseEl.innerHTML = "";
};


